import os
import time
import google.generativeai as genai
from google.generativeai.types import HarmCategory, HarmBlockThreshold

try:
    from config import GEMINI_API_KEY, TAG_RETRY_BASE_MS
except ImportError:
    from .config import GEMINI_API_KEY, TAG_RETRY_BASE_MS

ALLOWED_TAGS = [
    # Frontend
    "frontend", "react", "nextjs", "javascript", "typescript", "css", "web", "ui/ux", "design",
    # Backend
    "backend", "nodejs", "nestjs", "spring", "java", "python", "go", "api", "database",
    # AI
    "ai", "ai-ml", "llm", "genai", "mlops", "nlp", "cv",
    # DevOps
    "devops", "kubernetes", "docker", "terraform", "monitoring", "logging", "sre", "cloud", "cicd",
    # Architecture
    "architecture", "scalability", "micro frontend", "monorepo", "module federation", "system design",
    # Else
    "career", "culture", "business", "product", "ad", "case-study",
]

def merge_and_dedupe(tags):
    normalized = []
    for tag in tags:
        if tag:
            normalized_tag = str(tag).lower().strip()
            if normalized_tag:
                normalized.append(normalized_tag)
    return list(dict.fromkeys(normalized))

def parse_tags_from_text(text):
    if not text:
        return []
    text = text.replace("[", "").replace("]", "")
    parts = [p.strip().lower() for p in text.replace("\n", ",").split(",") if p.strip()]
    return merge_and_dedupe(parts)

def build_prompt(title, summary="", author=""):
    allowed = ", ".join(ALLOWED_TAGS)
    return f"""
You are a concise tagger for a tech blog aggregator.
Article:
- Title: {title}
- Author/Blog: {author}
- Summary: {summary}

Task: Choose 3-6 tags that best describe the article from the allowed list.
Allowed List: {allowed}

Output Format: Comma-separated list only. No extra text.
""".strip()

def generate_with_gemini(prompt):
    if not GEMINI_API_KEY:
        print("⚠️ GEMINI_API_KEY is missing via config.")
        return ""

    try:
        genai.configure(api_key=GEMINI_API_KEY)
        model = genai.GenerativeModel("gemini-1.5-flash")

        response = model.generate_content(
            prompt,
            safety_settings={
                HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_NONE,
                HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_NONE,
                HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_NONE,
                HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
            }
        )
        return response.text
    except Exception as e:
        print(f"❌ Gemini request failed: {e}")
        return ""

def generate_tags_for_article(article):
    """
    article dict must contain: title, summary, author
    """
    if not GEMINI_API_KEY:
        return []

    try:
        prompt = build_prompt(
            title=article.get("title", ""),
            summary=article.get("summary", ""),
            author=article.get("author", "")
        )

        text = generate_with_gemini(prompt)
        parsed_tags = parse_tags_from_text(text)

        filtered = [tag for tag in parsed_tags if tag in ALLOWED_TAGS]
        result = merge_and_dedupe(filtered)[:6]
        return result
    except Exception as e:
        print(f"❌ Error generating tags: {e}")
        return []

def base_tags_from_feed_category(category):
    if not category:
        return []
    key = str(category).upper()
    if key == "FE":
        return ["frontend", "web"]
    elif key == "BE":
        return ["backend"]
    elif key == "AI":
        return ["ai"]
    elif key == "APP":
        return ["mobile"]
    return []
